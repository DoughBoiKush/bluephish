<?php 
require_once('../config.php');

global $DB;
$html='';
 $name =$_GET['data'];
 $someArray = json_decode($name, true);
foreach ($someArray as $value) {
 

$res =$DB->get_records_sql("SELECT * FROM mdl_course where fullname like '".$value."'");
foreach($res as $key){
	  $c_id = $key->id;
	  $course_name = $key->fullname;
}
$location =$DB->get_record('course_location',array('courseid'=>$c_id));
	
	$region = $DB->get_record('region',array('id'=>$location->region_id));
	$district = $DB->get_record('district',array('id'=>$location->district_id));
	$centre = $DB->get_record('training_centre',array('id'=>$location->centre_id));
		$name1 =  $region->region_name;
		$name2 =  $district->district_name;
		$name3 =  $centre->centre_name;

		if(!empty($name1) && !empty($name2) && !empty($name3)){

			 $html.="<h1 style='width:100%; text-align:center;'>".$course_name." </h1><div class='".$c_id."'><strong> Training Region : </strong>".$name1."<br><strong>Training District : </strong>".$name2." <br><strong>Training centre : </strong>". $name3 ."</div>
			 	<div class='link' style='text-align:center;'><a href='$CFG->wwwroot/course/view.php?id= $c_id'><button class='btn btn-primary'>Click to View </button></a></div>";
		}
}
$obj=array('data'=>$html);
echo json_encode($obj); 
