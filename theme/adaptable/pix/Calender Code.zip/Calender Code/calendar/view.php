<?php

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// NOTICE OF COPYRIGHT                                                     //
//                                                                         //
// Moodle - Calendar extension                                             //
//                                                                         //
// Copyright (C) 2003-2004  Greek School Network            www.sch.gr     //
//                                                                         //
// Designed by:                                                            //
//     Avgoustos Tsinakos (tsinakos@teikav.edu.gr)                         //
//     Jon Papaioannou (pj@moodle.org)                                     //
//                                                                         //
// Programming and development:                                            //
//     Jon Papaioannou (pj@moodle.org)                                     //
//                                                                         //
// For bugs, suggestions, etc contact:                                     //
//     Jon Papaioannou (pj@moodle.org)                                     //
//                                                                         //
// The current module was developed at the University of Macedonia         //
// (www.uom.gr) under the funding of the Greek School Network (www.sch.gr) //
// The aim of this project is to provide additional and improved           //
// functionality to the Asynchronous Distance Education service that the   //
// Greek School Network deploys.                                           //
//                                                                         //
// This program is free software; you can redistribute it and/or modify    //
// it under the terms of the GNU General Public License as published by    //
// the Free Software Foundation; either version 2 of the License, or       //
// (at your option) any later version.                                     //
//                                                                         //
// This program is distributed in the hope that it will be useful,         //
// but WITHOUT ANY WARRANTY; without even the implied warranty of          //
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           //
// GNU General Public License for more details:                            //
//                                                                         //
//          http://www.gnu.org/copyleft/gpl.html                           //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////

/**
 * Display the calendar page.
 * @copyright 2003 Jon Papaioannou
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 * @package core_calendar
 */

require_once('../config.php');
require_once($CFG->dirroot.'/course/lib.php');
require_once($CFG->dirroot.'/calendar/lib.php');
global $DB, $USER;
$categoryid = optional_param('category', null, PARAM_INT);
$courseid = optional_param('course', SITEID, PARAM_INT);
$view = optional_param('view', 'upcoming', PARAM_ALPHA);
$time = optional_param('time', 0, PARAM_INT);

$url = new moodle_url('/calendar/view.php');

if (empty($time)) {
    $time = time();
}

if ($courseid != SITEID) {
    $url->param('course', $courseid);
}

if ($categoryid) {
    $url->param('categoryid', $categoryid);
}

if ($view !== 'upcoming') {
    $time = usergetmidnight($time);
    $url->param('view', $view);
}

$url->param('time', $time);

$PAGE->set_url($url);

$course = get_course($courseid);

if ($courseid != SITEID && !empty($courseid)) {
    navigation_node::override_active_url(new moodle_url('/course/view.php', array('id' => $course->id)));
} else if (!empty($categoryid)) {
    $PAGE->set_category_by_id($categoryid);
    navigation_node::override_active_url(new moodle_url('/course/index.php', array('categoryid' => $categoryid)));
} else {
    $PAGE->set_context(context_system::instance());
}

require_login($course, false);

$calendar = calendar_information::create($time, $courseid, $categoryid);

$pagetitle = '';

$strcalendar = get_string('calendar', 'calendar');

switch($view) {
    case 'day':
        $PAGE->navbar->add(userdate($time, get_string('strftimedate')));
        $pagetitle = get_string('dayviewtitle', 'calendar', userdate($time, get_string('strftimedaydate')));
    break;
    case 'month':
        $PAGE->navbar->add(userdate($time, get_string('strftimemonthyear')));
        $pagetitle = get_string('detailedmonthviewtitle', 'calendar', userdate($time, get_string('strftimemonthyear')));
    break;
    case 'upcoming':
        $pagetitle = get_string('upcomingevents', 'calendar');
    break;
}

// Print title and header
$PAGE->set_pagelayout('course');
$PAGE->set_title("$course->shortname: $strcalendar: $pagetitle");
$PAGE->set_heading($COURSE->fullname);

$renderer = $PAGE->get_renderer('core_calendar');
$calendar->add_sidecalendar_blocks($renderer, true, $view);

echo $OUTPUT->header();
echo $renderer->start_layout();
echo html_writer::start_tag('div', array('class'=>'heightcontainer'));
echo $OUTPUT->heading(get_string('calendar', 'calendar'));


list($data, $template) = calendar_get_view($calendar, $view);
echo $renderer->render_from_template($template, $data);

echo html_writer::end_tag('div');

list($data, $template) = calendar_get_footer_options($calendar);
echo $renderer->render_from_template($template, $data);

echo $renderer->complete_layout();

/*$course=$DB->get_records_sql("SELECT * from {course} where startdate=time()");
foreach ($course as $key) {
  echo $coursename=$key->fullname;
  echo "<br>";
}*/
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
                $('.day').click(function(){
                  
                  var nameArray = [];
                   $(this).find('ul').find('li').each(function(){
                      var ev_name=$(this).find('.eventname').text();
                      nameArray.push(ev_name);
                   });
                        var name = $(this).attr('title');
                        $.ajax({
                     method:"GET",  
                     data:{data:JSON.stringify(nameArray)},
                      contentType: 'application/json; charset=utf-8',
                     dataType: 'json',
                     async: true,
                     url:"getlocation.php",
                 /*   success:function(result){
                          $('.modal-body ').html(result);    
                          alert(result);   
                        $('.calendar_event_site .close').click();
                        $('#modal1').click();
                    }*/

                  }).done(function(result) {  
                       var coursedata = JSON.stringify(result)
                       //   alert(result);   
                      var obj = $.parseJSON(coursedata);
                    
                         $('.modal-body ').html(obj.data);                           
                        $('#modal1').click();
})
.fail(function(data) {
    console.log("error: ", data);
});;
                });
      

    $('.view-day-link').click(function(e){    
         e.preventDefault();
     });
      $('#close').click(function(){
          $('.modal-backdrop').remove();
      });

      if ($("div.hidden-phone").find("ul").length > 0){ 
        $('.hidden-phone').css("color","black");
        
         $('.hidden-phone').parent().css("background","lightgreen");
         $('.today').css("background","#e87804");
        $('.hidden-phone').append("<br><span style='font-size:8px;'>View Training</span>");
        $('.today .hidden-phone').css("color","white");
        }
    });
</script>
<script type="text/javascript">
     var popit = true;
     window.onbeforeunload = function() { 
          if(popit == true) {
               popit = false;
               return "Are you sure you want to leave?"; 
          }
     }
</script>
<style>
.modal{
    display: block;
}
.custom .modal{
    display: block;
    z-index: 1000000000;
}
.custom{
    z-index:10000000000000000;
    position: relative;
}
body#page-calendar-view .maincalendar .controls{
    background-color: transparent !important;
}
aside#block-region-side-post{
  display: none !important;
}
div#region-main-box {
    width: 100%;
}
section#region-main {
    width: 72%;
}
aside#block-region-side-pre {
    width: 27%;
}
div[data-region="day-content"] {
    display: none;
}
.today{
  color:white;
}
/*.day div ul li {
    display: none!important;
}*/
</style>

 <div class="custom">
<div class="modal fade " id="myModal" role="dialog" style="">
    <div class="modal-dialog" style="text-align:center;">
    <h5>TRAINING DETAILS</h5>
     <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
      <div class="modal-content">
        <div class="modal-header">
         
        </div>
        <div class="modal-body">
          <p class="location">Some text in the modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" id="close" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <button type="button" id="modal1"class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="display:none;">Open Modal</button>
</div>
  <?php
echo $OUTPUT->footer();
?>
  